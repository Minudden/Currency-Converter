let arr =[
    {
        "name":"AED",
        "value": 3.590696
    },
    {
        "name":"AFN",
        "value": 83.580837
    },
    {
        "name":"ALL",
        "value": 116.477067
    },
    {
        "name":"AMD",
        "value": 394.848653
    },
    {
        "name":"ANG",
        "value": 1.762263
    },
    {
        "name":"AOA",
        "value": 431.078962
    },
    {
        "name":"ARS",
        "value": 147.903251
    },
    {
        "name":"AUD",
        "value": 1.552173
    },
    {
        "name":"AWG",
        "value": 1.762061
    },
    {
        "name":"AZN",
        "value": 1.661142
    },
    {
        "name":"BAM",
        "value": 1.966492
    },
    {
        "name":"BBD",
        "value": 1.974304
    },
    {
        "name":"BDT",
        "value": 99.814965
    },
    {
        "name":"BGN",
        "value": 1.955581
    },
    {
        "name":"BHD",
        "value": 0.36853
    },
    {
        "name":"BIF",
        "value": 2005.963485
    },
    {
        "name":"BMD",
        "value": 0.977565
    },
    {
        "name":"BTC",
        "value": 0.000050352024
    },
    {
        "name":"CAD",
        "value": 1.345374
    },
    {
        "name":"CDF",
        "value": 2001.075765
    },
    {
        "name":"CHF",
        "value": 0.97815
    },
    {
        "name":"CRC",
        "value": 612.028225
    },
    {
        "name":"EUR",
        "value": 1
    },
    {
        "name":"GEL",
        "value": 2.708191
    },
    {
        "name":"INR",
        "value": 80.348955
    },
    {
        "name":"USD",
        "value": 0.977565
    }
    
]